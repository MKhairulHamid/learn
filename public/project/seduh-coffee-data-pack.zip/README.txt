Seduh Coffee — paket data bersih
================================

Ini dataset SETELAH pembersihan Sesi 2, dalam format yang diimpor sesi-sesi
berikutnya. Pakai ini kalau kamu bergabung di tengah program.

  products.csv, customers.csv, orders.csv, marketing_spend.csv
      Empat tabel yang sudah bersih. UTF-8, dipisah koma, tanggal ISO.

  orders_enriched.csv
      orders yang sudah di-join ke products dan customers, dengan rumus dari
      brief sudah diterapkan: net_unit_price, revenue, cogs, profit,
      discount_idr, is_completed, month. Praktis untuk Power BI — tapi bangun
      sendiri minimal sekali supaya kamu tahu isinya.

  schema.sql
      Definisi tabel lengkap dengan key dan index.

  seduh.db
      Database SQLite dengan keempat tabel sudah dimuat. Buka dengan
      DB Browser for SQLite, atau:  sqlite3 seduh.db

APA YANG DIBERSIHKAN
  Lihat tab Cleaning_Log di seduh-coffee-cleaned-*.xlsx — setiap aturan,
  alasannya, dan berapa baris yang terdampak.

APA YANG TIDAK
  - Rating kosong tetap kosong. Order tanpa rating bukan kesalahan data.
  - review_text kosong tetap kosong; sebagian besar order memang tidak diulas.
  - Order Returned dan Cancelled masih ada. Hanya 'Completed' yang dihitung
    sebagai revenue, tapi yang lain dibutuhkan untuk mengukur return rate.

INGAT
  Revenue per baris = quantity x unit_price x (1 - discount_pct)
  Profit  per baris = revenue - (quantity x unit_cost)
  Tanggal snapshot RFM = 1 Januari 2026
