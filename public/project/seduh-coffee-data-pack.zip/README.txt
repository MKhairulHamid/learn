Seduh Coffee — cleaned data pack
================================

This is the dataset AFTER the Session 2 cleaning, in the formats the later
sessions import from. Use it if you joined the program part-way through.

  products.csv, customers.csv, orders.csv, marketing_spend.csv
      The four cleaned tables. UTF-8, comma-separated, ISO dates.

  orders_enriched.csv
      orders joined to products and customers, with the brief's formulas
      already applied: net_unit_price, revenue, cogs, profit, discount_idr,
      is_completed, month. Convenient for Power BI — but build it yourself
      at least once so you know what is in it.

  schema.sql
      Table definitions with keys and indexes.

  seduh.db
      SQLite database with all four tables already loaded. Open it with
      DB Browser for SQLite, or:  sqlite3 seduh.db

WHAT WAS CLEANED
  See the Cleaning_Log tab in seduh-coffee-cleaned.xlsx — every rule, why it
  was applied, and how many rows it touched.

WHAT WAS NOT
  - Blank ratings are still blank. An unrated order is not an error.
  - Returned and Cancelled orders are still here. Only 'Completed' counts as
    revenue, but you need the others to measure the return rate.

REMEMBER
  Revenue per line = quantity x unit_price x (1 - discount_pct)
  Profit  per line = revenue - (quantity x unit_cost)
  RFM snapshot date = 1 January 2026
