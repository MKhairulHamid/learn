-- Seduh Coffee — schema for the cleaned dataset.
-- Load the CSVs in this order; the foreign keys depend on it.
--
--   sqlite3 seduh.db < schema.sql
--   sqlite3 seduh.db ".mode csv" ".import --skip 1 products.csv products" ...
--
-- Dates are stored as ISO text (YYYY-MM-DD) so SQLite date functions work.

DROP TABLE IF EXISTS orders;
DROP TABLE IF EXISTS marketing_spend;
DROP TABLE IF EXISTS customers;
DROP TABLE IF EXISTS products;

CREATE TABLE products (
  product_id  TEXT PRIMARY KEY,
  product_name TEXT NOT NULL,
  category    TEXT NOT NULL,
  base_price  INTEGER NOT NULL,
  unit_cost   INTEGER NOT NULL,
  launch_date TEXT NOT NULL
);

CREATE TABLE customers (
  customer_id         TEXT PRIMARY KEY,
  customer_name       TEXT NOT NULL,
  gender              TEXT NOT NULL,
  age                 INTEGER NOT NULL,
  city                TEXT NOT NULL,
  province            TEXT,
  signup_date         TEXT NOT NULL,
  acquisition_channel TEXT NOT NULL
);

CREATE TABLE orders (
  order_id       TEXT PRIMARY KEY,
  order_date     TEXT NOT NULL,
  customer_id    TEXT NOT NULL REFERENCES customers(customer_id),
  product_id     TEXT NOT NULL REFERENCES products(product_id),
  quantity       INTEGER NOT NULL,
  unit_price     INTEGER NOT NULL,
  discount_pct   REAL NOT NULL,
  channel        TEXT NOT NULL,
  payment_method TEXT NOT NULL,
  city           TEXT NOT NULL,
  province       TEXT NOT NULL,
  order_status   TEXT NOT NULL,
  rating         INTEGER          -- NULL means the order was never rated
);

CREATE TABLE marketing_spend (
  month       TEXT NOT NULL,
  channel     TEXT NOT NULL,
  spend_idr   INTEGER NOT NULL,
  impressions INTEGER NOT NULL,
  clicks      INTEGER NOT NULL,
  PRIMARY KEY (month, channel)
);

CREATE INDEX idx_orders_customer ON orders(customer_id);
CREATE INDEX idx_orders_product  ON orders(product_id);
CREATE INDEX idx_orders_date     ON orders(order_date);
CREATE INDEX idx_orders_status   ON orders(order_status);
